CREATE TABLE public.derived_actor (
	id         integer NOT NULL,
	name_kanji character varying,
	name_kana  character varying
);

